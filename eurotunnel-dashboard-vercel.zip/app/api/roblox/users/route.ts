import { NextResponse } from "next/server";

const usernames = ["HARRY2O6", "ericplane", "Abbinat0r"];

export async function GET() {
  try {
    const userRes = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames, excludeBannedUsers: true }),
      cache: "no-store",
    });
    if (!userRes.ok) return NextResponse.json({ error: "Roblox user service failed" }, { status: 502 });

    const userData = await userRes.json();
    const users = userData.data ?? [];
    if (!users.length) return NextResponse.json({ users: [] });

    const ids = users.map((u: { id: number }) => u.id);
    const [thumbRes, presenceRes] = await Promise.all([
      fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${ids.join(",")}&size=150x150&format=Png&isCircular=false`, { cache: "no-store" }),
      fetch("https://presence.roblox.com/v1/presence/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userIds: ids }),
        cache: "no-store",
      }),
    ]);

    const thumbs = thumbRes.ok ? await thumbRes.json() : { data: [] };
    const presence = presenceRes.ok ? await presenceRes.json() : { userPresences: [] };

    const avatarMap = new Map<number, string>();
    for (const item of thumbs.data ?? []) avatarMap.set(item.targetId, item.imageUrl);

    const presenceMap = new Map<number, number>();
    for (const item of presence.userPresences ?? []) presenceMap.set(item.userId, item.userPresenceType);

    return NextResponse.json({
      users: users.map((u: { id: number; name: string; displayName: string }) => ({
        id: u.id,
        name: u.name,
        displayName: u.displayName,
        avatar: avatarMap.get(u.id) ?? "",
        presenceType: presenceMap.get(u.id) ?? 0,
      })),
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to reach Roblox services" }, { status: 500 });
  }
}